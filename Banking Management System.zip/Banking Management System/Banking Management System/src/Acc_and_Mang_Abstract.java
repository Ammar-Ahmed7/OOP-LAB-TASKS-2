public abstract class Acc_and_Mang_Abstract {
    public abstract void Login();
}

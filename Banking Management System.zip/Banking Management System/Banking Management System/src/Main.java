public class Main{
    public static void main(String[] args) {
       Acc_and_Mang_Abstract a =new Accountant();
        System.out.println(a);
    }
}
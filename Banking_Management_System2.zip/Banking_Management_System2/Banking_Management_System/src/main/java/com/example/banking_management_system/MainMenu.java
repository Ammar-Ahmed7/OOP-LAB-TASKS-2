package com.example.banking_management_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class MainMenu {

    @FXML
    private TextField Date;

    @FXML
    private TextField Username;

    @FXML
    private Button back;

    @FXML
    private Button change_Pin;

    @FXML
    private Button create_Account;

    @FXML
    private Button customer_List;

    @FXML
    private Label date;

    @FXML
    private Button deposit;

    @FXML
    private Button exit;

    @FXML
    private Button profile;

    @FXML
    private Button transaction;

    @FXML
    private Button transfer;

    @FXML
    private Label username;

    @FXML
    private Button veiw_Balance;

    @FXML
    private Button withdraw;

    @FXML
    void currentDate(ActionEvent event) {

    }

    @FXML
    void onBalanceClicked(ActionEvent event) {

    }

    @FXML
    void onChangepinClicked(ActionEvent event) {

    }

    @FXML
    void onCreateaccountClicked(ActionEvent event) {

    }

    @FXML
    void onCustomerlistClicked(ActionEvent event) {

    }

    @FXML
    void onDepositClicked(ActionEvent event) {

    }

    @FXML
    void onTransferClicked(ActionEvent event) {

    }

    @FXML
    void onTrasactionClicked(ActionEvent event) {

    }

    @FXML
    void onWithdrawClicked(ActionEvent event) {

    }

    @FXML
    void onbackClicked(ActionEvent event) {

    }

    @FXML
    void onexitClicked(ActionEvent event) {

    }

    @FXML
    void seeProfile(ActionEvent event) {

    }

}

package com.example.banking_management_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ViewBalance {

    @FXML
    private Label Accountno;

    @FXML
    private Label Accountno_label;

    @FXML
    private Label Balance;

    @FXML
    private Label Balance_Label;

    @FXML
    private Button Clear_Button;

    @FXML
    private Label Name;

    @FXML
    private TextField Name_TextField;

    @FXML
    private Button back;

    @FXML
    void onClearButtonClicked(ActionEvent event) {

    }

    @FXML
    void onbackClicked(ActionEvent event) {

    }

}

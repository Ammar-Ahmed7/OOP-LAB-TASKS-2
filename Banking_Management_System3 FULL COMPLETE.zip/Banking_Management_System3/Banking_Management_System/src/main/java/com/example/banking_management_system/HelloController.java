package com.example.banking_management_system;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;

public class HelloController {

    @FXML
    private ImageView image;

}

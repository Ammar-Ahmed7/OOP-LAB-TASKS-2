package com.example.lab1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.io.IOException;
import java.text.spi.NumberFormatProvider;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        stage.setTitle("My Form");
        GridPane grid= new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));
        Scene s=new Scene(grid,500,600);
        stage.setScene(s);
        stage.show();


        Text sceneTitle= new Text("Registration Form");
        sceneTitle.setTextAlignment(TextAlignment.CENTER);
        sceneTitle.setFont(Font.font("Tahoma", FontWeight.BOLD,20));
        grid.add(sceneTitle,5,2);

        Label name=new Label("Name");
        name.setFont(Font.font("Tahoma",FontWeight.NORMAL,15));
        grid.add(name,2,4);
        TextField na=new TextField();
        grid.add(na,6,4);

        Label email=new Label("E-mail");
        email.setFont(Font.font("Tahoma",FontWeight.NORMAL,15));
        grid.add(email,2,5);
        TextField em=new TextField();
        grid.add(em,6,5);


        Label password=new Label("Password");
        password.setFont(Font.font("Tahoma",FontWeight.NORMAL,15));
        grid.add(password,2,6);
        PasswordField passwordField= new PasswordField();
        grid.add(passwordField,6,6);

        Label phone= new Label("Phone");
        phone.setFont(Font.font("Tahoma",FontWeight.NORMAL,15));
        grid.add(phone,2,7);
        ChoiceBox choiceBox=new ChoiceBox<TextField>();
        grid.add(choiceBox,5,7);
        TextField ph=new TextField();
        ph.setAlignment(Pos.BASELINE_LEFT);
        grid.add(ph,6,7);

        Label gender=new Label("Gender");
        gender.setFont(Font.font("Tahoma",FontWeight.NORMAL,15));
        grid.add(gender,2,8);
        ToggleButton tg=new ToggleButton();
        RadioButton radioButton=new RadioButton("Male");
        RadioButton radioButton1=new RadioButton("Female");
        grid.add(radioButton,5,8);
        grid.add(radioButton1,6,8);




    }

    public static void main(String[] args) {
        launch();
    }
}
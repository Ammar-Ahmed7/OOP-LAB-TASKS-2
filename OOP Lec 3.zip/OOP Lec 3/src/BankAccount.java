public class BankAccount {
    private String firstName;
    private String lastName;
    private double openingBalance;
    private int accountNum;
    private String email;


    public BankAccount(String firstName,String lastName,Double openingBalance,int accountNum){


        this.firstName=firstName;
        this.lastName=lastName;
        this.openingBalance=openingBalance;
        this.accountNum=this.accountNum++;
        this.email="No email Provided";

    }



    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getOpeningBalance() {
        return openingBalance;
    }

    public void setOpeningBalance(double openingBalance) {
        this.openingBalance = openingBalance;
    }

    public int getAccountNum() {
        return accountNum;
    }

 /*   public void setAccountNum(int accountNum) {
        this.accountNum = accountNum;
    }*/

    public void display()
    {
        System.out.printf("First Name = %s %n",getFirstName());
        System.out.printf("Last Name = %s %n",getLastName());
        System.out.printf("OpeningBalance = %.2f %n",getOpeningBalance());
        System.out.printf("AccountNumber = %d %n",getAccountNum());

    }
}

public class Demo {
    public static void main(String[] args){

        BankAccount acc1= new BankAccount("Ammar","Ahmed",17.9,100);
        BankAccount acc2= new BankAccount("Mikaal","Amjad",19.9,200);

            acc1.display();
            acc2.display();
    }
}

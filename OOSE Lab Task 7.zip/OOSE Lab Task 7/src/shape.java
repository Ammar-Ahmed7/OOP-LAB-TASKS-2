
public abstract  class shape {
    public abstract double getArea();
    public abstract double getPerimeter();
}

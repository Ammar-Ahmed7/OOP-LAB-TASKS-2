public class test {
    public static void main(String[] args) {

        TicTacToe game = new TicTacToe();
        game.gameboard();
    }
}
